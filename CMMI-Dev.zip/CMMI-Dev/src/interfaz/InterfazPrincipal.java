package interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class InterfazPrincipal extends JFrame 
{
	/**
	 * Versi�n de serializaci�n
	 */
	private static final long serialVersionUID = 7189248425442892801L;
	
	// Atributos ------------------------------------------------------------------------
	
	/**
	 * Representa el panel donde ir�n las categor�as.
	 */
	private PanelCategoria panelCategoria;
	
	/**
	 * Representa el panel donde ir�n los niveles.
	 */
	private PanelNivel panelNivel;
	
	/**
	 * Representa el panel donde ir� la tabla de registros.
	 */
	private PanelTabla panelTabla;
	
	// Constructor -----------------------------------------------------------------------
	
	public InterfazPrincipal() 
	{
		setTitle("CMMI-Dev");
		setSize(433, 409);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(new BorderLayout());
		
		
	}

	public static void main(String[] args) 
	{
		InterfazPrincipal ventana = new InterfazPrincipal();
		ventana.setLocationRelativeTo(null);
		ventana.setVisible(true);
	}

}
