package interfaz;

import javax.swing.JPanel;

public class PanelTabla extends JPanel
{

	/**
	 * Versi�n de serializaci�n
	 */
	private static final long serialVersionUID = -5749253243964571749L;

}
