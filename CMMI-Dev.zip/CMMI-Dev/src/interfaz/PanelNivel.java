package interfaz;

import javax.swing.JPanel;

public class PanelNivel extends JPanel
{

	/**
	 * Versi�n de serializaci�n
	 */
	private static final long serialVersionUID = 975627952074901691L;

}
