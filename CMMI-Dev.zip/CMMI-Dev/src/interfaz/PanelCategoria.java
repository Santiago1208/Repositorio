package interfaz;

import javax.swing.JPanel;

public class PanelCategoria extends JPanel
{

	/**
	 * Versi�n de serializaci�n
	 */
	private static final long serialVersionUID = 2971778626403338731L;

}
