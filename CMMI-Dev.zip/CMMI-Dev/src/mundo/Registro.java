package mundo;

public class Registro 
{
	// Atributos -----------------------------------------------------------------
	
	private String areaProceso;
	
	private String categoria;
	
	private int nivelMadurez;
	
	// Constructor ---------------------------------------------------------------
	
	public Registro(String areaP, String cat, int nivMad)
	{
		areaProceso = areaP;
		categoria = cat;
		nivelMadurez = nivMad;
	}
	
	// M�todos fundamentales -----------------------------------------------------

	public String darAreaProceso() 
	{
		return areaProceso;
	}

	public String darCategoria()
	{
		return categoria;
	}

	public int darNivelMadurez() 
	{
		return nivelMadurez;
	}
}
