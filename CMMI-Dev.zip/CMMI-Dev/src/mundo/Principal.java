package mundo;

import java.io.File;
import java.util.ArrayList;

public class Principal 
{
	
	// Atributos --------------------------------------------------------------------
	
	/**
	 * Representa la lista de registros.
	 */
	private ArrayList<Registro> registros;
	
	// Constructor ------------------------------------------------------------------
	
	public Principal(File archivo) 
	{
		registros = new ArrayList<>();
		importarRegistros(archivo);
	}

	
	// M�todos fundamentales --------------------------------------------------------
	
	public ArrayList<Registro> darRegistros() 
	{
		return registros;
	}

	public void modificarRegistros(ArrayList<Registro> registros)
	{
		this.registros = registros;
	}
	
	// M�todos y servicios -----------------------------------------------------------
	
	public ArrayList<Registro> filtrarPorCategoria(String categoria)
	{
		return null;
	}
	
	public ArrayList<Registro> filtrarPorMadurez(int nivel)
	{
		return null;
	}
	
	public ArrayList<Registro> filtrarPorCategoriaYNivel()
	{
		return null;
	}
	
	private void importarRegistros(File archivo)
	{
		
	}

}
